# Spiderman Selfbot dont skid this shit nigga ill kill you
# https://www.youtube.com/watch?v=ddUjgGNecog

## Important Notice
This code is being sold  by me (muz/g8ng) dont try to resell ts nigga. If you got it from someone other than me then you got scammed

## Contact Information
- Discord: discord.gg/says
- Discrd Username: @g8ng

## DONT FUCKING SELL IT
I've noticed that certain individuals have been attempting to resell this code for profit. This practice goes against my wishes.

Feel free to reach out to me through discord if you have any questions or concerns.

